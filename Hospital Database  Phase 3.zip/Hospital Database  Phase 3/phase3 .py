import mysql.connector
#from connect import create_connection
from mysql.connector import Error


def create_connection():
    try:
        cnx = mysql.connector.connect(
            user="root", password="12345", host='127.0.0.1' ,database="hospital"
        )
        print("Connection established with the database")
        return cnx
    except mysql.connector.Error as err:
        if err.errno == Error.ER_ACCESS_DENIED_ERROR:
            print("Something is wrong with your user name or password")
        elif err.errno == Error.ER_BAD_DB_ERROR:
            print("Database does not exist")
        else:
            print(err)
        cnx.close()
        return None
    

# Function to execute a query
def execute_query(connection, query, data=None):
    cursor = connection.cursor()
    try:
        if data:
            cursor.execute(query, data)
        else:
            cursor.execute(query)
        connection.commit()
        print(query)
        print("Query executed successfully")
    except Error as e:
        print(f"Error: {e}")
    finally:
        cursor.close()

# Insert Operation for Patients
def insert_patients(connection, data):
    query = "INSERT INTO patients (p_id, gender, p_name, contact, bday) VALUES (%s, %s, %s, %s, %s)"
    execute_query(connection, query, data)

# Insert Operation for stays_in_room
def insert_stays_in_room(connection, data):
    query = "INSERT INTO stays_in_room (p_id, room_id, stay_in) VALUES (%s, %s, %s)"
    execute_query(connection, query, data)


# Read Operation
def read_patients(connection):
    query = "SELECT * FROM patients"
    cursor = connection.cursor(dictionary=True)
    try:
        cursor.execute(query)
        records = cursor.fetchall()
        print(query)
        for record in records:
            print(record)
    except Error as e:
        print(f"Error: {e}")
    finally:
        cursor.close()


# Read Operation
def read_stays_in_room(connection):
    query = "SELECT * FROM stays_in_room"
    cursor = connection.cursor(dictionary=True)
    try:
        cursor.execute(query)
        records = cursor.fetchall()
        print(query)
        for record in records:
            print(record)
    except Error as e:
        print(f"Error: {e}")
    finally:
        cursor.close()


# Update Operation
def update_patient_contact(connection, p_id, new_contact):
    query = "UPDATE patients SET contact = %s WHERE p_id = %s"
    data = (new_contact, p_id)
    execute_query(connection, query, data)


# Update Operation
def update_stays_in_room_stay_in(connection, p_id, new_stay_in):
    query = "UPDATE stays_in_room SET stay_in = %s WHERE p_id = %s"
    data = (new_stay_in, p_id)
    execute_query(connection, query, data)


# Delete Operation
def delete_patient(connection, p_id):
    query = "DELETE FROM patients WHERE p_id = %s"
    data = (p_id,)
    execute_query(connection, query, data)


# Delete Operation
def delete_stays_in_room(connection, p_id):
    query = "DELETE FROM stays_in_room WHERE p_id = %s"
    data = (p_id,)
    execute_query(connection, query, data)



# Main function
def main():

    connection = create_connection()
    cursor = connection.cursor()

    # First insert these values to your table
    patient_values_to_insert = [

        (11, 'M', 'John Doe', 'johndoe@gmail.com', '1980-01-01'),
        (12, 'F', 'Jane Smith', 'janesmith@hotmail.com', '1990-02-02')
    ]

    room_values_to_insert = [

        (11, 102, '2024-04-25'),
        (12, 104, '2024-04-24')
    ]
    
    # Read my Patients table
    read_patients(connection)
    print("--------------------------------------------------")
    # Read my stays_in_room table
    read_stays_in_room(connection)

    for patient in patient_values_to_insert:
        insert_patients(connection, patient)
    
    for stays_in_room in room_values_to_insert:
        insert_stays_in_room(connection, stays_in_room)
    
    # Read my Patients table
    read_patients(connection)
    # Update the patient information
    update_patient_contact(connection, 2, "new_emily_mail@gmail.com")
    # Read my Patients table to see the updated information
    read_patients(connection)
    # Delete the patient
    delete_patient(connection, 3)
    # Read my Patients table to see that there exist or not exist deleted patient in table
    read_patients(connection)

    print("--------------------------------------------------")
    print("--------------------------------------------------")
    print("--------------------------------------------------")

    # Read my stays_in_room table
    read_stays_in_room(connection)
    # Update the stays_in_room information
    update_stays_in_room_stay_in(connection, 5, '2024-04-26')
    # Read my stays_in_room table to see the updated information
    read_stays_in_room(connection)
    # Delete the room information of spesific patient
    delete_stays_in_room(connection, 6)
    # Read my stays_in_room table to see that there exist or not exist information of deleted patient in table
    read_stays_in_room(connection)
    read_patients(connection)
    
    if connection:
        connection.close()
        print("Connection closed")


if __name__ == "__main__":
    main()
